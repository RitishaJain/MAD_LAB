package com.example.program5_practice;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbHelper extends SQLiteOpenHelper {

    public DbHelper(MainActivity context)
    {
        super(context,"userDB",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (username TEXT, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    public void addUser(User user){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username",user.getUsername());
        contentValues.put("password",user.getPassword());

        db.insert("users",null,contentValues);
        db.close();
    }

    public int checkUser(User user){
        int userExists = -1;
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT username,password FROM users WHERE username=? AND password=?",new String[]{user.getUsername(),user.getPassword()});

        if(cursor.getCount() > 0){
            cursor.moveToFirst();
            userExists = cursor.getInt(0);
            cursor.close();
        }

        return  userExists;
    }
}
