(function () {
	self.addEventListener("install", (event) => {
		event.waitUntil(
			caches.open("version1").then((cache) => {
				console.log("Caching Assets");
				cache.addAll([
					"/",
					"/index.html",
					"/main.js",
					"/error.html",
					"/success.html",
					"/images/icons/icon-256x256.png",
				]);
			})
		);
		console.log("Service Worker Installed", event);
	});

	self.addEventListener("activate", (event) => {
		console.log("Activated", event);
	});

	self.addEventListener("fetch", (event) => {
		// console.log("fetch ", event);
		event.respondWith(
			caches.match(event.request).then((cacheResponse) => {
				return cacheResponse || fetch(event.request);
			})
		);
	});
})();
